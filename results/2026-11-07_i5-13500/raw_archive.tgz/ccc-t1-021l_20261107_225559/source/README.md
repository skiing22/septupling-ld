# Benchmark for "On the Minimality of Chain-Based Septupling"

Produces every measured number in the paper (Tables 3, 10, 11, 12 and the (2^n-1)P timings),
re-checks every LD block and chain against the affine group law on K-163, B-233 and B-283
(NIST parameters; the program verifies G on the curve and n*G = O), and records the machine.

| File | Purpose |
|---|---|
| `ld_common.h` | Field and curve setup, affine group law, the LD blocks of Appendix A, the chains of Eqs. (6) and (7) |
| `bench.cpp` | Part 1 correctness, Part 2 field costs (Table 3), Part 3 block and chain costs (Tables 11, 12) |
| `run_all.sh` | Records the platform, builds, runs 3 pinned runs, summarises, packs one `.tgz` |
| `record_platform.sh` | CPU, OS, kernel, clocks, turbo, governor, libraries, virtualisation |
| `freq_log.sh` | Logs the pinned core's clock every 0.2 s during each run |
| `summarize.py` | Medians across runs, ratios, predicted vs measured, savings |
| `tools/enumerate_chains.py` | Table 10 (pure Python) |
| `tools/small_curve_orders.py` | Counts of points of exact order 5 and 6 on the small test curves (Sec. 4.4) |

    sudo apt install g++ libntl-dev libgf2x-dev libgmp-dev python3   # or conda, see below
    CORE=2 QUICK=1 ./run_all.sh     # about 1 minute; must print ALL CORRECTNESS CHECKS PASSED
    CORE=2 ./run_all.sh             # about 10 minutes; keep the results_*.tgz it prints

Without sudo: `conda install -c conda-forge ntl gf2x gmp`, then run inside the activated
environment; `run_all.sh` uses `$CONDA_PREFIX` automatically.

Protocol: rdtsc with lfence before and after; 3 warm-ups and 15 timed repetitions, median;
field operations 2^20 per repetition (inversion 2^14), blocks 2^16 on their own output,
chains 2^14 repeated evaluations; three independent process runs on one pinned core.
